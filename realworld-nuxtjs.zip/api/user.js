import { request } from '@/utils/request'
export const login = data => {
    return request({
        method:'POST',
        url:'api/users/login',
        data
    })
}

//用户注册
export const register = data => {
    return request({
        method: 'POST',
        url:'api/users',
        data
    })
}




    name:'LoginIndex',
    computed: {
        isLogin() {
            return this.$route.name === 'login'
        }
    },
    data() {
      return {
        user: {
          email: '',
          password: ''
        }
      }
    },
    methods: {
      async onSubmit () {
        //提交表单请求登录
        const { data } = await request({
          methods:'POST',
          url:'/api/users/login',
          data: {
            user: this.user
          }
        })
        console.log(data);
        //TODO: 保存用户的登录状态

        //跳转到首页
        this.$router.push('/')
      }
    }
}
