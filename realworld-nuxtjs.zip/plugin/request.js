import axios from 'axios'
export const request = axios.create({
    baseURL:'http://realworld.api.fed.lagounews.com'
})
 //插件导出函数必须作为default成员 
export default ({store}) => {
    //请求拦截器
    //Add a request inteceptor
    //任何请求都要经过请求拦截器
    //我们可以在请求拦截器中做一些公共的业务处理，例如同一设置token
    request.interceptors.request.use(function(config){
        //Do somethin before request is sent
        //请求就会经过这里
        const {user} = store.state
        if(user && user.token) {
            config.headers.Authorization = `Token ${user.token}`
        }
        return config
    },function(error){
        //如果请求失败（此时请求还没有发出去）就会进入这里
        //Do something with request error
        return Promise.reject(error);
    });
    //响应拦截器
}




